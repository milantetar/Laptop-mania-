<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}

// Securely get the logged-in user's email
$user_email = htmlspecialchars($_SESSION['user']['email']);

// CSRF Token Generation for Form Security
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        die("CSRF validation failed.");
    }

    $name = htmlspecialchars($_POST['name']);
    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
    $message = htmlspecialchars($_POST['message']);

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        die("Invalid email format.");
    }

    // Database connection
    include 'db_connect.php';

    $stmt = $conn->prepare("INSERT INTO contact_messages (name, email, message) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $name, $email, $message);

    if ($stmt->execute()) {
        $_SESSION['message_status'] = "Message sent successfully!";
        header("Location: contactus.php");
        exit();
    } else {
        $_SESSION['message_status'] = "Failed to send message.";
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us - Laptopmania</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/project/styles.css">
    <style>
        .container {
            position: relative;
            z-index: 1;
            max-width: 800px;
            margin: 50px auto;
        }
        .contact-section {
            background: rgba(255, 255, 255, 0.98);
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
        }
        h2, h3 {
            color: #ff4500; /* Tangerine */
            text-shadow: 1px 1px 3px rgba(0, 0, 0, 0.5);
        }
        p, li, strong {
            color: #2d3436;
            text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.3);
        }
        .form-label {
            color: #2d3436;
            text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.3);
        }
        .form-control {
            background: rgba(255, 255, 255, 0.95);
            color: #2d3436;
            border: 1px solid #d4af37; /* Gold border */
        }
        .form-control::placeholder {
            color: #6c757d;
        }
        .form-control:focus {
            border-color: #20b2aa; /* Seafoam green */
            box-shadow: 0 0 10px rgba(32, 178, 170, 0.5);
        }
        .profile-icon span {
            color: #ffffff;
            text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.4);
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg">
        <div class="container-fluid">
            <a href="/project/homepage.php">
                <img src="/project/img/logo.png" height="35px" width="150px" alt="logo">
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link" href="/project/homepage.php">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="/project/products.php">Products</a></li>
                    <li class="nav-item"><a class="nav-link active" href="/project/contactus.php">Contact</a></li>
                    <li class="nav-item"><a class="nav-link" href="/project/logout.php">Logout</a></li>
                </ul>
                <div class="profile-icon ms-3">
                    <a href="/project/profile.php" class="text-decoration-none d-flex align-items-center">
                        <img src="/project/img/user.png" alt="Profile" class="rounded-circle me-2" width="40" height="40">
                        <span><?= $user_email; ?></span>
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Contact Us Section -->
    <div class="container my-5">
        <div class="contact-section">
            <h2>Contact Us</h2>
            <p>We would love to hear from you! Fill out the form below, and we will get back to you as soon as possible.</p>

            <!-- Display Message -->
            <?php if (isset($_SESSION['message_status'])): ?>
                <div class="alert alert-info"><?= $_SESSION['message_status']; unset($_SESSION['message_status']); ?></div>
            <?php endif; ?>

            <!-- Contact Form -->
            <form action="" method="POST">
                <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token']; ?>">

                <div class="mb-3">
                    <label for="name" class="form-label">Your Name</label>
                    <input type="text" class="form-control" name="name" id="name" placeholder="Enter your name" pattern="[A-Za-z\s]+" required>
                </div>

                <div class="mb-3">
                    <label for="email" class="form-label">Email Address</label>
                    <input type="email" class="form-control" name="email" id="email" placeholder="Enter your email" required>
                </div>

                <div class="mb-3">
                    <label for="message" class="form-label">Your Message</label>
                    <textarea class="form-control" name="message" id="message" rows="4" placeholder="Write your message" required></textarea>
                </div>

                <button type="submit" class="btn btn-primary w-100">Send Message</button>
            </form>
        </div>
    </div>

    <!-- Contact Information -->
    <div class="container my-5">
        <div class="contact-section">
            <h3>Our Contact Information</h3>
            <p>If you prefer, you can reach out to us through the following:</p>
            <ul>
                <li><strong>Email:</strong> support@laptopmania.com</li>
                <li><strong>Phone:</strong> +1 800 123 4567</li>
                <li><strong>Address:</strong> 123 Laptop Street, City, Country</li>
            </ul>
        </div>
    </div>

    <!-- Footer -->
    <footer class="footer text-center py-3">
        <p>© 2025 Laptopmania. All Rights Reserved.</p>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>