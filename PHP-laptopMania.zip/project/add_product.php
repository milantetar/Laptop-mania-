<?php
session_start();
require 'db_connect.php';

if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}

$error = $success = "";
$categories = [];
$stmt = $conn->prepare("SELECT id, name FROM categories");
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $categories[] = $row;
}
$stmt->close();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $product_name = filter_input(INPUT_POST, 'product_name', FILTER_SANITIZE_STRING);
    $product_description = filter_input(INPUT_POST, 'product_description', FILTER_SANITIZE_STRING);
    $product_price = filter_input(INPUT_POST, 'product_price', FILTER_VALIDATE_FLOAT);
    $category_id = filter_input(INPUT_POST, 'category_id', FILTER_VALIDATE_INT);
    $product_image = $_FILES['product_image'] ?? null;

    if (!$product_name || !$product_description || $product_price === false || !$category_id || !$product_image || $product_image['error'] !== UPLOAD_ERR_OK) {
        $error = "All fields are required, and a valid image must be uploaded. Error: " . ($product_image['error'] ?? 'No file');
    } else {
        $image_filename = strtolower(basename($product_image['name']));
        $image_path = "/laptopmania/project/img/" . $image_filename;
        $upload_path = $_SERVER['DOCUMENT_ROOT'] . $image_path;

        if (!is_dir(dirname($upload_path))) {
            mkdir(dirname($upload_path), 0755, true);
        }

        if (move_uploaded_file($product_image['tmp_name'], $upload_path)) {
            $stmt = $conn->prepare("INSERT INTO products (name, description, price, image_path, category_id) VALUES (?, ?, ?, ?, ?)");
            $stmt->bind_param("ssdsi", $product_name, $product_description, $product_price, $image_path, $category_id);
            if ($stmt->execute()) {
                $success = "Product added successfully! Image saved to: " . $image_path;
                header("Location: manage_products.php?success=" . urlencode($success));
                exit();
            } else {
                $error = "Error adding product: " . $conn->error;
                unlink($upload_path);
            }
            $stmt->close();
        } else {
            $error = "Failed to upload image. Error: " . $product_image['error'] . " - Path: " . $upload_path;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Product - Laptopmania</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="/project/styles.css">
    <style>
        .container {
            max-width: 600px;
            background: rgba(255, 255, 255, 0.98);
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
            margin-top: 50px;
            position: relative;
            z-index: 1;
        }
        h2 {
            text-align: center;
            margin-bottom: 20px;
            font-weight: 600;
            color: #ff4500; /* Tangerine */
            text-shadow: 1px 1px 3px rgba(0, 0, 0, 0.5);
        }
        .form-control {
            border-radius: 8px;
            background: rgba(255, 255, 255, 0.95);
            color: #2d3436;
            border: 1px solid #d4af37; /* Gold border */
        }
        .form-control::placeholder {
            color: #6c757d;
        }
        .form-control:focus {
            border-color: #20b2aa; /* Seafoam green */
            box-shadow: 0 0 10px rgba(32, 178, 170, 0.5);
        }
        .form-label {
            color: #2d3436;
            text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.3);
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="container">
            <a class="navbar-brand" href="admin_dashboard.php">
                <img src="/project/img/logo.png" alt="Laptopmania Logo" width="150" height="35">
            </a>
            <a href="logout.php" class="btn btn-danger">Logout</a>
        </div>
    </nav>

    <div class="container">
        <h2><i class="bi bi-laptop"></i> Add a New Product</h2>
        <?php if ($success): ?>
            <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
        <?php elseif ($error): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <form action="add_product.php" method="POST" enctype="multipart/form-data">
            <div class="mb-3">
                <label for="productName" class="form-label">Product Name</label>
                <input type="text" class="form-control" id="productName" name="product_name" placeholder="Enter product name" required>
            </div>
            <div class="mb-3">
                <label for="productDescription" class="form-label">Product Description</label>
                <textarea class="form-control" id="productDescription" name="product_description" rows="4" placeholder="Enter product description" required></textarea>
            </div>
            <div class="mb-3">
                <label for="productPrice" class="form-label">Product Price ($)</label>
                <input type="number" step="0.01" class="form-control" id="productPrice" name="product_price" placeholder="Enter product price" required>
            </div>
            <div class="mb-3">
                <label for="categoryId" class="form-label">Category</label>
                <select class="form-control" id="categoryId" name="category_id" required>
                    <option value="">Select a category</option>
                    <?php foreach ($categories as $category): ?>
                        <option value="<?= $category['id'] ?>"><?= htmlspecialchars($category['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="mb-3">
                <label for="productImage" class="form-label">Product Image</label>
                <input type="file" class="form-control" id="productImage" name="product_image" accept="image/*" required>
            </div>
            <button type="submit" class="btn btn-primary">Add Product</button>
        </form>
    </div>

    <footer class="footer text-center py-3 mt-4">
        <p>© <?= date('Y') ?> Laptopmania. All rights reserved.</p>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>