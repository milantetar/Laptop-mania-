<?php
session_start();

// Check if user is already logged in
if (isset($_SESSION['user'])) {
    header("Location: homepage.php");
    exit();
}

// Generate CSRF token if not set
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Database connection
require 'db_connect.php';

// Include PHPMailer classes
require 'vendor/autoload.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$error = $success = "";
$loading = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Verify CSRF token
    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'] ?? '')) {
        $error = "Invalid CSRF token. Please try again.";
    } else {
        $email = filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL);

        if (!$email) {
            $error = "Please enter a valid email address.";
        } else {
            // Check if email exists
            $stmt = $conn->prepare("SELECT email FROM users WHERE email = ?");
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                $loading = true; // Start loading state
                $token = bin2hex(random_bytes(32));
                $expires = date('Y-m-d H:i:s', strtotime('+1 hour')); // Token valid for 1 hour

                // Update user with token and expiration
                $stmt = $conn->prepare("UPDATE users SET reset_token = ?, reset_expires = ? WHERE email = ?");
                $stmt->bind_param("sss", $token, $expires, $email);
                if ($stmt->execute()) {
                    // Send reset email using PHPMailer
                    $mail = new PHPMailer(true);
                    try {
                        $mail->isSMTP();
                        $mail->Host = 'smtp.gmail.com';
                        $mail->SMTPAuth = true;
                        $mail->Username = 'your-email@gmail.com'; // Replace with your Gmail
                        $mail->Password = 'your-app-password';    // Replace with your app password
                        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                        $mail->Port = 587;
                        $mail->SMTPDebug = 0; // Set to 2 for debugging if needed

                        $mail->setFrom('no-reply@laptopmania.com', 'Laptopmania');
                        $mail->addAddress($email);

                        $mail->isHTML(false);
                        $mail->Subject = "Password Reset Request";
                        $reset_link = "http://" . $_SERVER['HTTP_HOST'] . "/project/reset_password.php?token=" . $token;
                        $mail->Body = "Click the link to reset your password: $reset_link\nThis link expires in 1 hour.";

                        $mail->send();
                        $success = "A password reset link has been sent to your email. Check your inbox or spam folder.";
                        $loading = false; // Stop loading state
                    } catch (Exception $e) {
                        $error = "Failed to send reset email. Mailer Error: " . $mail->ErrorInfo . " Please try again or contact support.";
                        $loading = false; // Stop loading state
                    }
                } else {
                    $error = "Error updating reset request. Please try again.";
                    $loading = false; // Stop loading state
                }
                $stmt->close();
            } else {
                $error = "No account found with that email.";
            }
        }
    }
    // Regenerate CSRF token after submission
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password - Laptopmania</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/project/styles.css">
    <style>
        body { background-color: #212529; color: #f8f9fa; }
        .forgot-password { max-width: 400px; margin: 50px auto; background-color: #343a40; padding: 20px; border-radius: 8px; }
        .btn-primary { background-color: #ffc107; border: none; color: #212529; }
        .btn-primary:hover { background-color: #e0a800; }
        .alert { margin-top: 10px; }
        .loading { display: none; position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); }
        .loading.active { display: block; }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="/project/homepage.php">
                <img src="/project/img/logo.png" height="35" width="150" alt="Laptopmania Logo">
            </a>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link" href="/project/login.php">Login</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container">
        <div class="forgot-password">
            <h2 class="text-center mb-4" style="color: #ffc107;">Forgot Password</h2>
            <?php if ($error): ?>
                <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
                <?php if (strpos($error, 'Mailer Error') !== false): ?>
                    <p class="text-center mt-2"><a href="" class="text-info" onclick="this.form.submit(); return false;">Resend Email</a></p>
                <?php endif; ?>
            <?php endif; ?>
            <?php if ($success): ?>
                <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
            <?php endif; ?>
            <form method="POST" action="" id="resetForm" onsubmit="showLoading()">
                <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                <div class="mb-3">
                    <label for="email" class="form-label">Email Address</label>
                    <input type="email" class="form-control" id="email" name="email" required pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" title="Please enter a valid email address">
                </div>
                <button type="submit" class="btn btn-primary w-100" id="submitBtn" <?= $loading ? 'disabled' : '' ?>>Send Reset Link</button>
            </form>
            <div class="text-center mt-3">
                <a href="/project/login.php" class="text-decoration-none text-info">Back to Login</a>
            </div>
        </div>
    </div>

    <!-- Loading Spinner -->
    <div class="loading active" id="loadingSpinner">
        <div class="spinner-border text-warning" role="status">
            <span class="visually-hidden">Loading...</span>
        </div>
    </div>

    <footer class="footer bg-dark text-center text-light py-3 mt-4">
        <img src="/project/img/logo.png" height="35" width="140" alt="Laptopmania Logo">
        <p>© <?= date("Y"); ?> Laptopmania. All rights reserved.</p>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function showLoading() {
            document.getElementById('loadingSpinner').classList.add('active');
            document.getElementById('submitBtn').disabled = true;
        }

        // Hide loading on page load if not needed
        window.onload = function() {
            if (!<?= json_encode($loading) ?>) {
                document.getElementById('loadingSpinner').classList.remove('active');
                document.getElementById('submitBtn').disabled = false;
            }
        };
    </script>
</body>
</html>