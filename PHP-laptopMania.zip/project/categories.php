<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}

$inactive = 900;
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity']) > $inactive) {
    session_unset();
    session_destroy();
    header("Location: login.php");
    exit();
}
$_SESSION['last_activity'] = time();

if (!isset($_SESSION['created'])) {
    $_SESSION['created'] = time();
} elseif (time() - $_SESSION['created'] > 1800) {
    session_regenerate_id(true);
    $_SESSION['created'] = time();
}

$user_email = htmlspecialchars($_SESSION['user']['email']);

// Database connection
require 'db_connect.php';

// Pagination and filtering
$page = filter_input(INPUT_GET, 'page', FILTER_VALIDATE_INT, ['options' => ['default' => 1, 'min_range' => 1]]);
$category_filter = filter_input(INPUT_GET, 'category', FILTER_SANITIZE_STRING);
$per_page = 8;

$category_stmt = $conn->prepare("SELECT id, name FROM categories");
$category_stmt->execute();
$categories = $category_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$category_stmt->close();

$categories_data = [];
$total_products = 0;

$category_condition = $category_filter ? "AND category_id = (SELECT id FROM categories WHERE name = ?)" : "";
$offset = ($page - 1) * $per_page;

$stmt = $conn->prepare("SELECT c.name AS category_name, p.id, p.name, p.price, p.image_path 
                       FROM products p 
                       JOIN categories c ON p.category_id = c.id 
                       WHERE 1=1 $category_condition 
                       LIMIT ? OFFSET ?");
if ($category_filter) {
    $stmt->bind_param("sii", $category_filter, $per_page, $offset);
} else {
    $stmt->bind_param("ii", $per_page, $offset);
}
$stmt->execute();
$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
    $categories_data[$row['category_name']][] = [
        'id' => $row['id'],
        'name' => $row['name'],
        'price' => $row['price'],
        'image' => $row['image_path'] ?: '/project/img/placeholder.jpg'
    ];
    $total_products++;
}
$stmt->close();

// Calculate total pages
$total_pages = ceil($total_products / $per_page);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laptopmania - Categories</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/project/styles.css">
    <style>
        .container { position: relative; z-index: 1; }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg">
        <div class="container-fluid">
            <a class="navbar-brand" href="/project/homepage.php">
                <img src="/project/img/logo.png" height="35" width="150" alt="Laptopmania Logo">
            </a>
            <form class="d-flex ms-auto search-bar-container" action="search.php" method="GET">
                <input type="text" class="form-control me-2 search-bar" name="query" placeholder="Search laptops..." required>
                <button class="btn search-button" type="submit">Search</button>
            </form>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link" href="/project/homepage.php">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="/project/products.php">Products</a></li>
                    <li class="nav-item"><a class="nav-link active" href="/project/categories.php">Categories</a></li>
                    <li class="nav-item"><a class="nav-link" href="/project/contactus.php">Contact</a></li>
                    <li class="nav-item"><a class="nav-link" href="/project/logout.php">Logout</a></li>
                </ul>
                <div class="d-flex align-items-center ms-3 profile-icon">
                    <a href="/project/profile.php" class="text-decoration-none d-flex align-items-center">
                        <div class="profile-image">
                            <img src="/project/img/user.png" alt="Profile" class="rounded-circle me-2">
                        </div>
                        <span class="text-white"><?= $user_email; ?></span>
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <!-- Category Filter -->
        <div class="category-filter mb-4">
            <form method="GET" action="" class="d-flex">
                <select name="category" class="form-select me-2" onchange="this.form.submit()">
                    <option value="">All Categories</option>
                    <?php foreach ($categories as $category): ?>
                        <option value="<?= htmlspecialchars($category['name']) ?>" <?= $category_filter === $category['name'] ? 'selected' : '' ?>>
                            <?= htmlspecialchars($category['name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <button type="submit" class="btn btn-primary">Filter</button>
            </form>
        </div>

        <?php if (!empty($categories_data)): ?>
            <?php foreach ($categories_data as $category_name => $laptops): ?>
                <h5 class="mt-4"><?= htmlspecialchars($category_name); ?></h5>
                <div class="row">
                    <?php foreach ($laptops as $laptop): ?>
                        <div class="col-md-3 mb-4">
                            <div class="product-card">
                                <img src="<?= htmlspecialchars($laptop['image']) ?>" 
                                     class="card-img-top" alt="<?= htmlspecialchars($laptop['name']) ?>" 
                                     onerror="this.src='/project/img/placeholder.jpg';">
                                <div class="card-body text-center">
                                    <h6 class="card-title"><?= htmlspecialchars($laptop['name']) ?></h6>
                                    <p class="card-text">Price: $<?= number_format($laptop['price'], 2); ?></p>
                                    <form action="add_to_cart.php" method="POST">
                                        <input type="hidden" name="product_id" value="<?= $laptop['id']; ?>">
                                        <input type="hidden" name="product_name" value="<?= htmlspecialchars($laptop['name']); ?>">
                                        <input type="hidden" name="product_price" value="<?= $laptop['price']; ?>">
                                        <button type="submit" class="btn btn-primary w-100 mb-2">Add to Cart</button>
                                    </form>
                                    <a href="product_details.php?id=<?= $laptop['id'] ?>" class="btn btn-info w-100">View Details</a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p class="text-center">No products found in the selected category.</p>
        <?php endif; ?>

        <!-- Pagination -->
        <?php if ($total_pages > 1): ?>
            <nav aria-label="Page navigation">
                <ul class="pagination">
                    <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                        <li class="page-item <?= $i === $page ? 'active' : '' ?>">
                            <a class="page-link" href="?page=<?= $i ?><?= $category_filter ? '&category=' . urlencode($category_filter) : '' ?>">
                                <?= $i ?>
                            </a>
                        </li>
                    <?php endfor; ?>
                </ul>
            </nav>
        <?php endif; ?>
    </div>

    <footer class="footer text-center py-3 mt-4">
        <img src="/project/img/logo.png" height="35" width="140" alt="Laptopmania Logo">
        <p>© <?= date("Y"); ?> Laptopmania. All rights reserved.</p>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>