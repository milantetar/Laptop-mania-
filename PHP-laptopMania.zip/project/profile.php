<?php
session_start();
require 'db_connect.php'; // Database connection

// Redirect if not logged in
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}

$user_email = $_SESSION['user']['email'];

// Fetch user details from database
$stmt = $conn->prepare("SELECT fullname, email FROM users WHERE email = ?");
$stmt->bind_param("s", $user_email);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

// Handle password update
$success = "";
$error = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $current_password = $_POST['current_password'] ?? '';
    $new_password = $_POST['new_password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';

    if (!$current_password || !$new_password || !$confirm_password) {
        $error = "All fields are required.";
    } elseif ($new_password !== $confirm_password) {
        $error = "New passwords do not match.";
    } else {
        $stmt = $conn->prepare("SELECT password FROM users WHERE email = ?");
        $stmt->bind_param("s", $user_email);
        $stmt->execute();
        $result = $stmt->get_result();
        $user_data = $result->fetch_assoc();

        if (!password_verify($current_password, $user_data['password'])) {
            $error = "Current password is incorrect.";
        } else {
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("UPDATE users SET password = ? WHERE email = ?");
            $stmt->bind_param("ss", $hashed_password, $user_email);
            if ($stmt->execute()) {
                $success = "Password updated successfully.";
            } else {
                $error = "Error updating password.";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile - Laptopmania</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="/project/styles.css">
    <style>
        /* Classy tangerine K-drama theme */
        .container {
            position: relative;
            z-index: 1;
        }
        .card {
            background: rgba(255, 255, 255, 0.9); /* Glassmorphism effect */
            backdrop-filter: blur(10px);
            border: 2px solid #d4af37; /* Gold border */
            border-radius: 15px;
            box-shadow: 0 0 20px rgba(212, 175, 55, 0.3);
        }
        .card h5 {
            font-family: 'Playfair Display', serif;
            color: #2d3436;
        }
    </style>
</head>
<body class="d-flex flex-column min-vh-100">
    <nav class="navbar">
        <div class="container">
            <a class="navbar-brand" href="/project/homepage.php">
                <img src="/project/img/logo.png" alt="Laptopmania Logo" width="150" height="35">
            </a>
            <div class="d-flex align-items-center">
                <a class="nav-link text-white me-3" href="/project/logout.php">Logout</a>
            </div>
        </div>
    </nav>

    <div class="container mt-5">
        <h2 class="mb-4">Profile</h2>
        
        <?php if ($success): ?>
            <div class="alert alert-success"> <?= $success; ?> </div>
        <?php elseif ($error): ?>
            <div class="alert alert-danger"> <?= $error; ?> </div>
        <?php endif; ?>

        <div class="card p-4 shadow mb-4">
            <h5>Name: <?= htmlspecialchars($user['fullname']); ?></h5>
            <h5>Email: <?= htmlspecialchars($user['email']); ?></h5>
        </div>

        <h3 class="mt-4">Change Password</h3>
        <form method="POST">
            <div class="mb-3">
                <label for="current_password" class="form-label">Current Password</label>
                <div class="input-group">
                    <span class="input-group-text"><i class="bi bi-lock"></i></span>
                    <input type="password" class="form-control" id="current_password" name="current_password" required>
                    <span class="input-group-text toggle-password" onclick="togglePassword('current_password', this)">
                        <i class="bi bi-eye-slash"></i>
                    </span>
                </div>
            </div>
            <div class="mb-3">
                <label for="new_password" class="form-label">New Password</label>
                <div class="input-group">
                    <span class="input-group-text"><i class="bi bi-lock"></i></span>
                    <input type="password" class="form-control" id="new_password" name="new_password" required>
                    <span class="input-group-text toggle-password" onclick="togglePassword('new_password', this)">
                        <i class="bi bi-eye-slash"></i>
                    </span>
                </div>
            </div>
            <div class="mb-3">
                <label for="confirm_password" class="form-label">Confirm New Password</label>
                <div class="input-group">
                    <span class="input-group-text"><i class="bi bi-lock"></i></span>
                    <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                    <span class="input-group-text toggle-password" onclick="togglePassword('confirm_password', this)">
                        <i class="bi bi-eye-slash"></i>
                    </span>
                </div>
            </div>
            <button type="submit" class="btn btn-primary">Update Password</button>
            <a href="homepage.php" class="btn btn-secondary ms-2">Back to Home</a>
        </form>
    </div>

    <footer class="footer mt-auto">
        <div class="container py-4">
            <p class="text-center small">© <?= date('Y') ?> Laptopmania. All rights reserved.</p>
        </div>
    </footer>

    <script>
        function togglePassword(fieldId, iconElement) {
            var passwordField = document.getElementById(fieldId);
            var icon = iconElement.querySelector("i");

            if (passwordField.type === "password") {
                passwordField.type = "text";
                icon.classList.remove("bi-eye-slash");
                icon.classList.add("bi-eye");
            } else {
                passwordField.type = "password";
                icon.classList.remove("bi-eye");
                icon.classList.add("bi-eye-slash");
            }
        }
    </script>
</body>
</html>