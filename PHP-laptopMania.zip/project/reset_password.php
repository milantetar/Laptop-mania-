<?php
session_start();

// Check if user is already logged in
if (isset($_SESSION['user'])) {
    header("Location: homepage.php");
    exit();
}

// Database connection
require 'db_connect.php';

$error = $success = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = filter_input(INPUT_POST, 'token', FILTER_SANITIZE_STRING);
    $password = filter_input(INPUT_POST, 'password', FILTER_SANITIZE_STRING);
    $confirm_password = filter_input(INPUT_POST, 'confirm_password', FILTER_SANITIZE_STRING);

    if ($password && $confirm_password && $password === $confirm_password) {
        $stmt = $conn->prepare("SELECT email FROM users WHERE reset_token = ? AND reset_expires > NOW()");
        $stmt->bind_param("s", $token);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc();
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);

            $stmt = $conn->prepare("UPDATE users SET password = ?, reset_token = NULL, reset_expires = NULL WHERE email = ?");
            $stmt->bind_param("ss", $hashed_password, $user['email']);
            if ($stmt->execute()) {
                $success = "Password reset successfully. <a href='/project/login.php'>Login here</a>.";
            } else {
                $error = "Error updating password. Please try again.";
            }
            $stmt->close();
        } else {
            $error = "Invalid or expired token.";
        }
    } else {
        $error = "Passwords do not match or are invalid.";
    }
} elseif (isset($_GET['token'])) {
    $token = filter_input(INPUT_GET, 'token', FILTER_SANITIZE_STRING);
    $stmt = $conn->prepare("SELECT reset_token FROM users WHERE reset_token = ? AND reset_expires > NOW()");
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        $error = "Invalid or expired token.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password - Laptopmania</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/project/styles.css">
    <style>
        body { background-color: #212529; color: #f8f9fa; }
        .reset-password { max-width: 400px; margin: 50px auto; background-color: #343a40; padding: 20px; border-radius: 8px; }
        .btn-primary { background-color: #ffc107; border: none; color: #212529; }
        .btn-primary:hover { background-color: #e0a800; }
        .alert { margin-top: 10px; }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="/project/homepage.php">
                <img src="/project/img/logo.png" height="35" width="150" alt="Laptopmania Logo">
            </a>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link" href="/project/login.php">Login</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container">
        <div class="reset-password">
            <h2 class="text-center mb-4" style="color: #ffc107;">Reset Password</h2>
            <?php if ($error): ?>
                <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
            <?php endif; ?>
            <?php if ($success): ?>
                <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
            <?php else: ?>
                <form method="POST" action="">
                    <input type="hidden" name="token" value="<?= htmlspecialchars($_GET['token'] ?? '') ?>">
                    <div class="mb-3">
                        <label for="password" class="form-label">New Password</label>
                        <input type="password" class="form-control" id="password" name="password" required>
                    </div>
                    <div class="mb-3">
                        <label for="confirm_password" class="form-label">Confirm Password</label>
                        <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                    </div>
                    <button type="submit" class="btn btn-primary w-100">Reset Password</button>
                </form>
            <?php endif; ?>
            <div class="text-center mt-3">
                <a href="/project/login.php" class="text-decoration-none text-info">Back to Login</a>
            </div>
        </div>
    </div>

    <footer class="footer bg-dark text-center text-light py-3 mt-4">
        <img src="/project/img/logo.png" height="35" width="140" alt="Laptopmania Logo">
        <p>© <?= date("Y"); ?> Laptopmania. All rights reserved.</p>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>