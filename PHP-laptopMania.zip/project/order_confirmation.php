<?php
session_start();

if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}

if (!isset($_SESSION['order'])) {
    $error = "No recent order found.";
} else {
    $order = $_SESSION['order'];
    $error = "";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Confirmation - Laptopmania</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/project/styles.css">
    <style>
        .order-confirmation {
            max-width: 600px;
            margin: 50px auto;
            background: rgba(255, 255, 255, 0.98);
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
            position: relative;
            z-index: 1;
        }
        h2 {
            color: #20b2aa; /* Seafoam green */
            text-shadow: 1px 1px 3px rgba(0, 0, 0, 0.5);
        }
        h5 {
            color: #ff4500; /* Tangerine */
            text-shadow: 1px 1px 3px rgba(0, 0, 0, 0.5);
        }
        p, strong {
            color: #2d3436;
            text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.3);
        }
        .table th, .table td {
            color: #2d3436;
            text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.3);
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg">
        <div class="container-fluid">
            <img src="/project/img/logo.png" height="35px" width="150px" alt="logo">
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link" href="/project/products.php">Continue Shopping</a></li>
                    <li class="nav-item"><a class="nav-link" href="/project/logout.php">Logout</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container">
        <div class="order-confirmation">
            <h2 class="text-center mb-4">Order Confirmation</h2>
            <?php if ($error): ?>
                <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
            <?php elseif ($order): ?>
                <div class="alert alert-success text-center">
                    Thank you for your order, <?= htmlspecialchars($order['name']) ?>!
                </div>
                <div class="order-details">
                    <h5>Order Details</h5>
                    <p><strong>Order Date:</strong> <?= htmlspecialchars($order['order_date']) ?></p>
                    <p><strong>Shipping Address:</strong> <?= htmlspecialchars($order['address']) ?></p>
                    <p><strong>Email Confirmation Sent To:</strong> <?= htmlspecialchars($order['email']) ?></p>
                    <table class="table mt-3">
                        <thead>
                            <tr>
                                <th>Product</th>
                                <th>Quantity</th>
                                <th>Price</th>
                                <th>Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($order['cart'] as $id => $item): ?>
                                <tr>
                                    <td><?= htmlspecialchars($item['name']) ?></td>
                                    <td><?= htmlspecialchars($item['quantity']) ?></td>
                                    <td>$<?= number_format($item['price'], 2) ?></td>
                                    <td>$<?= number_format($item['price'] * $item['quantity'], 2) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                    <p><strong>Total Amount:</strong> $<?= number_format($order['total'], 2) ?></p>
                </div>
                <div class="text-center mt-4">
                    <a href="/project/products.php" class="btn btn-success">Continue Shopping</a>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <footer class="footer mt-4 text-center">
        <img src="/project/img/logo.png" height="35px" width="140px" alt="logo">
        <p>© <?= date("Y"); ?> Laptopmania. All rights reserved.</p>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>