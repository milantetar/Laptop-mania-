<?php
session_start(); // Start the session

// Check if the user is logged in
if (!isset($_SESSION['user'])) {
    header("Location: login.php"); // Redirect to login page if not logged in
    exit();
}

// Security Enhancements
$inactive = 900; // 15 minutes timeout
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity']) > $inactive) {
    session_unset();
    session_destroy();
    header("Location: login.php"); // Redirect to login after timeout
    exit();
}
$_SESSION['last_activity'] = time(); // Update last activity timestamp

// Prevent session fixation attacks
if (!isset($_SESSION['created'])) {
    $_SESSION['created'] = time();
} elseif (time() - $_SESSION['created'] > 1800) { // Regenerate session every 30 minutes
    session_regenerate_id(true);
    $_SESSION['created'] = time();
}

$user_email = htmlspecialchars($_SESSION['user']['email']); // Prevent XSS attacks

// Database connection
require 'db_connect.php';

// Fetch categories from database
$stmt = $conn->prepare("SELECT id, name FROM categories");
$stmt->execute();
$categories_result = $stmt->get_result();
$categories = [];

while ($category = $categories_result->fetch_assoc()) {
    $categories[$category['name']] = [];

    $product_stmt = $conn->prepare("SELECT id, name, price, image_path, description FROM products WHERE category_id = ?");
    $product_stmt->bind_param("i", $category['id']);
    $product_stmt->execute();
    $products_result = $product_stmt->get_result();

    while ($product = $products_result->fetch_assoc()) {
        $categories[$category['name']][] = [
            'id' => $product['id'],
            'name' => $product['name'],
            'price' => $product['price'],
            'image' => $product['image_path'] ?: '/project/img/placeholder.jpg',
            'description' => $product['description']
        ];
    }
    $product_stmt->close();
}
$stmt->close();

// Calculate cart item count
$cart_count = isset($_SESSION['cart']) ? array_sum(array_column($_SESSION['cart'], 'quantity')) : 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laptopmania - Homepage</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="/project/styles.css">
    <style>
        /* Inline styles to enhance the tangerine K-drama theme */
        .card { border: none; transition: transform 0.3s ease, box-shadow 0.3s ease; }
        .card:hover { transform: scale(1.05); box-shadow: 0 0 20px rgba(255, 140, 0, 0.5); }
        .card-img-top { width: 100%; height: 200px; object-fit: cover; border-radius: 10px 10px 0 0; }
        h5 { color: #ff4500; text-shadow: 0 0 5px rgba(255, 69, 0, 0.3); }
        .cart-icon {
            position: relative;
        }
        .cart-count {
            position: absolute;
            top: -10px;
            right: -10px;
            background: linear-gradient(45deg, #ff8c00, #ffd700); /* Tangerine to yellow */
            color: #2d3436;
            border-radius: 50%;
            padding: 2px 8px;
            font-size: 12px;
            box-shadow: 0 0 10px rgba(255, 215, 0, 0.5);
        }
        .quick-view-btn {
            background: linear-gradient(45deg, #1e90ff, #20b2aa); /* Blue to seafoam green */
            color: #ffffff;
            border: none;
            border-radius: 10px;
            transition: background 0.3s ease, box-shadow 0.3s ease;
        }
        .quick-view-btn:hover {
            background: linear-gradient(45deg, #40c4ff, #40e0d0); /* Lighter gradient on hover */
            box-shadow: 0 0 15px rgba(32, 178, 170, 0.7);
        }
        .modal-content {
            background: linear-gradient(135deg, #ffd700 0%, #ff8c00 100%); /* Yellow to tangerine */
            color: #2d3436;
            border-radius: 15px;
        }
        .modal-header, .modal-footer {
            border-color: #20b2aa; /* Seafoam green borders */
        }
        .btn-outline-primary {
            border-color: #1e90ff; /* Ocean blue */
            color: #1e90ff;
            background: transparent;
        }
        .btn-outline-primary:hover {
            background: #1e90ff;
            color: #ffffff;
            box-shadow: 0 0 10px rgba(30, 144, 255, 0.5);
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg">
        <div class="container-fluid">
            <a class="navbar-brand" href="/project/homepage.php">
                <img src="/project/img/logo.png" height="35" width="150" alt="Laptopmania Logo">
            </a>
            <form class="d-flex search-bar-container" action="search.php" method="GET">
                <input class="search-bar" type="text" name="query" placeholder="Search" required>
                <button class="search-button" type="submit">Search</button>
            </form>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link active" href="/project/homepage.php">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="/project/products.php">Products</a></li>
                    <li class="nav-item"><a class="nav-link" href="/project/contactus.php">Contact</a></li>
                    <li class="nav-item">
                        <a class="nav-link cart-icon" href="/project/checkout.php">
                            <i class="bi bi-cart"></i>
                            <?php if ($cart_count > 0): ?>
                                <span class="cart-count"><?= $cart_count ?></span>
                            <?php endif; ?>
                        </a>
                    </li>
                    <li class="nav-item"><a class="nav-link" href="/project/logout.php">Logout</a></li>
                </ul>
                <div class="d-flex align-items-center ms-3 profile-icon">
                    <a href="/project/profile.php" class="text-decoration-none d-flex align-items-center">
                        <div class="profile-image">
                            <img src="/project/img/user.png" alt="Profile" class="rounded-circle me-2" width="40" height="40">
                        </div>
                        <span><?= $user_email; ?></span>
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="mb-4">
            <a class="btn btn-outline-primary" href="/project/categories.php">All Categories</a>
        </div>
        <?php
        $seen_products = [];
        foreach ($categories as $category_name => $laptops):
        ?>
            <h5 class="mt-4"><?= htmlspecialchars($category_name); ?></h5>
            <div class="row">
                <?php foreach ($laptops as $laptop):
                    if (!in_array($laptop['id'], $seen_products)) {
                        $seen_products[] = $laptop['id'];
                ?>
                    <div class="col-md-3 mb-4">
                        <div class="card product-card">
                            <img src="<?= htmlspecialchars($laptop['image']) ?>" 
                                 class="card-img-top product-image" alt="<?= htmlspecialchars($laptop['name']) ?>" 
                                 onerror="this.src='/project/img/placeholder.jpg';">
                            <div class="card-body product-details text-center">
                                <h6 class="card-title"><?= htmlspecialchars($laptop['name']) ?></h6>
                                <p class="card-text">Price: $<?= number_format($laptop['price'], 2); ?></p>
                                <form action="add_to_cart.php" method="POST">
                                    <input type="hidden" name="product_id" value="<?= $laptop['id']; ?>">
                                    <input type="hidden" name="product_name" value="<?= htmlspecialchars($laptop['name']); ?>">
                                    <input type="hidden" name="product_price" value="<?= $laptop['price']; ?>">
                                    <button type="submit" class="btn">Add to Cart</button>
                                </form>
                                <button type="button" class="btn quick-view-btn mt-2" 
                                        data-bs-toggle="modal" 
                                        data-bs-target="#quickViewModal<?= $laptop['id'] ?>">
                                    Quick View
                                </button>
                                <a href="product_details.php?id=<?= $laptop['id'] ?>" class="btn mt-2">View Details</a>
                            </div>
                        </div>
                    </div>

                    <!-- Quick View Modal -->
                    <div class="modal fade" id="quickViewModal<?= $laptop['id'] ?>" tabindex="-1" aria-labelledby="quickViewModalLabel<?= $laptop['id'] ?>" aria-hidden="true">
                        <div class="modal-dialog modal-lg">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="quickViewModalLabel<?= $laptop['id'] ?>"><?= htmlspecialchars($laptop['name']) ?></h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <img src="<?= htmlspecialchars($laptop['image']) ?>" 
                                                 class="img-fluid rounded" 
                                                 alt="<?= htmlspecialchars($laptop['name']) ?>" 
                                                 onerror="this.src='/project/img/placeholder.jpg';">
                                        </div>
                                        <div class="col-md-6">
                                            <h6>Price: $<?= number_format($laptop['price'], 2); ?></h6>
                                            <p><?= htmlspecialchars($laptop['description']) ?: 'No description available.'; ?></p>
                                            <form action="add_to_cart.php" method="POST">
                                                <input type="hidden" name="product_id" value="<?= $laptop['id']; ?>">
                                                <input type="hidden" name="product_name" value="<?= htmlspecialchars($laptop['name']); ?>">
                                                <input type="hidden" name="product_price" value="<?= $laptop['price']; ?>">
                                                <button type="submit" class="btn btn-primary">Add to Cart</button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <a href="product_details.php?id=<?= $laptop['id'] ?>" class="btn btn-info">View Full Details</a>
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php } endforeach; ?>
            </div>
        <?php endforeach; ?>
    </div>

    <footer class="footer text-center py-3">
        <img src="/project/img/logo.png" height="35" width="140" alt="Laptopmania Logo">
        <p>© <?= date("Y"); ?> Laptopmania. All rights reserved.</p>
    </footer>
</body>
</html>