<?php
session_start();
require 'db_connect.php';

if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}

$success = isset($_GET['success']) ? $_GET['success'] : "";
$stmt = $conn->prepare("SELECT p.id, p.name, p.price, p.image_path, c.name AS category_name 
                        FROM products p 
                        LEFT JOIN categories c ON p.category_id = c.id");
$stmt->execute();
$products_result = $stmt->get_result();
$products = [];
while ($row = $products_result->fetch_assoc()) {
    $products[] = $row;
}
$stmt->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Products - Laptopmania</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="/project/styles.css">
    <style>
        .container {
            max-width: 1000px;
            margin-top: 50px;
            position: relative;
            z-index: 1;
        }
        .card {
            background: rgba(255, 255, 255, 0.98);
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
        }
        h2 {
            color: #ff4500; /* Tangerine */
            text-shadow: 1px 1px 3px rgba(0, 0, 0, 0.5);
        }
        .table th, .table td {
            color: #2d3436;
            text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.3);
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="container">
            <a class="navbar-brand" href="admin_dashboard.php">
                <img src="/project/img/logo.png" alt="Laptopmania Logo" width="150" height="35">
            </a>
            <a href="logout.php" class="btn btn-danger">Logout</a>
        </div>
    </nav>

    <div class="container">
        <div class="card p-4">
            <h2 class="text-center mb-4"><i class="bi bi-laptop"></i> Manage Products</h2>

            <?php if ($success): ?>
                <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
            <?php endif; ?>

            <a href="add_product.php" class="btn btn-primary mb-3"><i class="bi bi-plus-circle"></i> Add New Product</a>

            <?php if (empty($products)): ?>
                <p>No products found.</p>
            <?php else: ?>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Price</th>
                            <th>Category</th>
                            <th>Image</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($products as $product): ?>
                            <tr>
                                <td><?= $product['id'] ?></td>
                                <td><?= htmlspecialchars($product['name']) ?></td>
                                <td>$<?= number_format($product['price'], 2) ?></td>
                                <td><?= htmlspecialchars($product["category_name"] ?? 'Uncategorized') ?></td>
                                <td><img src="<?= $product['image_path'] ?>" alt="Product Image" width="50"></td>
                                <td>
                                    <a href="edit_product.php?id=<?= $product['id'] ?>" class="btn btn-primary btn-sm"><i class="bi bi-pencil"></i> Edit</a>
                                    <form action="delete_product.php" method="POST" style="display:inline;">
                                        <input type="hidden" name="product_id" value="<?= $product['id'] ?>">
                                        <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this product?');"><i class="bi bi-trash"></i> Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>

            <a href="admin_dashboard.php" class="btn btn-info w-100 mt-3">Back to Dashboard</a>
        </div>
    </div>

    <footer class="footer text-center py-3 mt-4">
        <p>© <?= date('Y') ?> Laptopmania. All rights reserved.</p>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>