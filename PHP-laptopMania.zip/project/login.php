<?php
session_start();
require 'db_connect.php';

if (isset($_SESSION['user'])) {
    header("Location: homepage.php");
    exit();
} elseif (isset($_SESSION['admin'])) {
    header("Location: admin_dashboard.php");
    exit();
}

$error = "";
function checkLoginAttempts($conn, $email) {
    $stmt = $conn->prepare("SELECT attempts, last_attempt FROM login_attempts WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if ($result && $result['attempts'] >= 5 && (time() - strtotime($result['last_attempt']) < 300)) {
        $remaining = 300 - (time() - strtotime($result['last_attempt']));
        return "Too many failed attempts. Try again in " . ceil($remaining / 60) . " minutes.";
    }
    return null;
}

function updateLoginAttempts($conn, $email, $success) {
    if ($success) {
        $stmt = $conn->prepare("DELETE FROM login_attempts WHERE email = ?");
    } else {
        $stmt = $conn->prepare("INSERT INTO login_attempts (email, attempts, last_attempt) 
            VALUES (?, 1, NOW()) ON DUPLICATE KEY UPDATE attempts = attempts + 1, last_attempt = NOW()");
    }
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->close();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
    $password = $_POST['password'] ?? '';
    $role = $_POST['role'] ?? 'user';
    $remember = isset($_POST['remember']) ? true : false;

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email format.";
    } else {
        $error = checkLoginAttempts($conn, $email);
        if (!$error && $email && $password) {
            $table = $role === 'admin' ? 'admin' : 'users';
            $stmt = $conn->prepare("SELECT id, email, password FROM $table WHERE email = ?");
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $result = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            if ($result && password_verify($password, $result['password'])) {
                if ($role === 'admin') {
                    $_SESSION['admin'] = $result['email'];
                    header("Location: admin_dashboard.php");
                } else {
                    $_SESSION['user'] = ['id' => $result['id'], 'email' => $result['email']];
                    header("Location: homepage.php");
                }
                if ($remember) {
                    setcookie('email', $email, time() + (30 * 24 * 60 * 60), "/"); // 30 days
                }
                session_regenerate_id(true);
                updateLoginAttempts($conn, $email, true);
                exit();
            } else {
                updateLoginAttempts($conn, $email, false);
                $error = "Invalid email or password.";
            }
        } elseif (!$error) {
            $error = "Please enter a valid email and password.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Laptopmania</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="/project/styles.css">
    <style>
        /* Classy tangerine K-drama theme */
        .auth-container {
            min-height: 100vh;
            display: grid;
            place-items: center;
            position: relative;
            overflow: hidden;
        }
        .auth-container::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320"><path fill="rgba(255,255,255,0.2)" fill-opacity="1" d="M0,160L48,176C96,192,192,224,288,213.3C384,203,480,149,576,138.7C672,128,768,160,864,181.3C960,203,1056,213,1152,197.3C1248,181,1344,139,1392,117.3L1440,96L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"></path></svg>') repeat-x bottom;
            animation: waveMove 10s linear infinite;
        }
        .card {
            max-width: 450px;
            background: rgba(255, 255, 255, 0.9); /* Glassmorphism effect */
            backdrop-filter: blur(10px);
            border: 2px solid #d4af37; /* Gold border */
            border-radius: 15px;
            box-shadow: 0 0 20px rgba(212, 175, 55, 0.3);
        }
        .card h2 {
            font-family: 'Playfair Display', serif;
            color: #ff4500; /* Tangerine */
            text-shadow: 0 0 5px rgba(255, 69, 0, 0.3);
        }
        .form-label {
            font-family: 'Playfair Display', serif;
            color: #2d3436;
        }
        .input-group-text {
            background: linear-gradient(45deg, #ff8c00, #ffd700); /* Tangerine to yellow */
            color: #2d3436;
            border: 1px solid #d4af37; /* Gold border */
        }
        .form-control {
            border: 1px solid #d4af37; /* Gold border */
            border-radius: 10px;
            background: rgba(255, 255, 255, 0.8);
            color: #2d3436;
        }
        .form-control:focus {
            border-color: #20b2aa; /* Seafoam green */
            box-shadow: 0 0 10px rgba(32, 178, 170, 0.5);
        }
        .btn-outline-secondary {
            border-color: #d4af37; /* Gold border */
            color: #2d3436;
        }
        .btn-outline-secondary:hover {
            background: #d4af37; /* Gold background on hover */
            color: #ffffff;
        }
        .form-check-label {
            color: #2d3436;
        }
        .btn-primary {
            background: linear-gradient(45deg, #1e90ff, #20b2aa); /* Blue to seafoam green */
            border: none;
            color: #ffffff;
            border-radius: 10px;
            font-family: 'Playfair Display', serif;
            transition: background 0.3s ease, box-shadow 0.3s ease;
        }
        .btn-primary:hover {
            background: linear-gradient(45deg, #40c4ff, #40e0d0);
            box-shadow: 0 0 15px rgba(32, 178, 170, 0.7);
        }
        .alert-danger {
            background: rgba(255, 69, 0, 0.1);
            border-color: #ff4500;
            color: #ff4500;
        }
        .text-center a {
            color: #1e90ff;
        }
        .text-center a:hover {
            color: #40c4ff;
            text-shadow: 0 0 10px rgba(64, 196, 255, 0.7);
        }
    </style>
</head>
<body class="d-flex flex-column min-vh-100">
    <nav class="navbar">
        <div class="container">
            <a class="navbar-brand" href="#">
                <img src="/project/img/logo.png" alt="Laptopmania Logo" width="150" height="35">
            </a>
        </div>
    </nav>

    <main class="auth-container">
        <div class="card shadow-lg p-4">
            <div class="text-center mb-4">
                <img src="/project/img/logo.png" alt="Logo" width="120" class="mb-3">
                <h2 class="h4">Sign In to Laptopmania</h2>
            </div>

            <?php if ($error): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <?= htmlspecialchars($error) ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <form method="POST" autocomplete="off" onsubmit="return validateForm()">
                <div class="mb-3">
                    <label for="email" class="form-label">Email</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="bi bi-envelope"></i></span>
                        <input type="email" class="form-control" id="email" name="email" 
                               value="<?= isset($_COOKIE['email']) ? htmlspecialchars($_COOKIE['email']) : '' ?>" 
                               placeholder="name@example.com" required autofocus>
                    </div>
                </div>
                <div class="mb-3">
                    <label for="password" class="form-label">Password</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="bi bi-lock"></i></span>
                        <input type="password" class="form-control" id="password" name="password" 
                               placeholder="••••••••" required>
                        <button class="btn btn-outline-secondary" type="button" id="togglePassword">
                            <i class="bi bi-eye"></i>
                        </button>
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label">Login As:</label>
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="role" id="user" value="user" checked>
                        <label class="form-check-label" for="user">User</label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="role" id="admin" value="admin">
                        <label class="form-check-label" for="admin">Admin</label>
                    </div>
                </div>
                <div class="mb-3 form-check">
                    <input type="checkbox" class="form-check-input" id="remember" name="remember">
                    <label class="form-check-label" for="remember">Remember me</label>
                </div>
                <button type="submit" class="btn btn-primary w-100">Sign In</button>
                <div class="text-center mt-3">
                    <p>Not registered? <a href="/project/registration.php">Create an account</a></p>
                    <p><a href="/project/forgot_password.php">Forgot Password?</a></p>
                </div>
            </form>
        </div>
    </main>

    <footer class="footer mt-auto py-3 text-center">
        <p>© <?= date('Y') ?> Laptopmania. All rights reserved.</p>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function validateForm() {
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;
            if (!email || !password) {
                alert('Please fill in all fields.');
                return false;
            }
            return true;
        }

        document.getElementById('togglePassword').addEventListener('click', function () {
            const password = document.getElementById('password');
            const icon = this.querySelector('i');
            password.type = password.type === 'password' ? 'text' : 'password';
            icon.classList.toggle('bi-eye');
            icon.classList.toggle('bi-eye-slash');
        });
    </script>
</body>
</html>