<?php
session_start();
require 'db_connect.php';

if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}

$product_count = $sales_count = $category_count = 0;
$sales_total = 0.00;

// Fetch total products
$stmt = $conn->prepare("SELECT COUNT(*) FROM products");
$stmt->execute();
$stmt->bind_result($product_count);
$stmt->fetch();
$stmt->close();

// Fetch total categories
$stmt = $conn->prepare("SELECT COUNT(*) FROM categories");
$stmt->execute();
$stmt->bind_result($category_count);
$stmt->fetch();
$stmt->close();

// Fetch total sales and amount
$stmt = $conn->prepare("SELECT COUNT(*), COALESCE(SUM(price), 0) FROM orders");
$stmt->execute();
$stmt->bind_result($sales_count, $sales_total);
$stmt->fetch();
$stmt->close();

// Fetch monthly sales data for the past 12 months
$monthly_sales = [];
$labels = [];
$current_date = new DateTime();
for ($i = 11; $i >= 0; $i--) {
    $date = (clone $current_date)->modify("-$i months");
    $labels[] = $date->format('M Y');
    $month_start = $date->format('Y-m-01 00:00:00');
    $month_end = $date->format('Y-m-t 23:59:59');

    $stmt = $conn->prepare("
        SELECT COALESCE(SUM(price), 0) as total
        FROM orders
        WHERE order_date BETWEEN ? AND ?
    ");
    $stmt->bind_param("ss", $month_start, $month_end);
    $stmt->execute();
    $stmt->bind_result($total);
    $stmt->fetch();
    $monthly_sales[] = $total;
    $stmt->close();
}

// Fetch sales by category
$sales_by_category = [];
$stmt = $conn->prepare("
    SELECT c.name, COUNT(o.id) as order_count, COALESCE(SUM(o.price), 0) as total_sales
    FROM orders o
    JOIN products p ON o.product_id = p.id
    JOIN categories c ON p.category_id = c.id
    GROUP BY c.id, c.name
    ORDER BY total_sales DESC
");
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $sales_by_category[] = $row;
}
$stmt->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Laptopmania</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="/project/styles.css">
    <style>
        .container { position: relative; z-index: 1; }
        .card {
            background: rgba(255, 255, 255, 0.98); /* More opaque for better text visibility */
            backdrop-filter: blur(10px);
            border: 2px solid #d4af37;
            border-radius: 15px;
            color: #2d3436;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2); /* Stronger shadow for depth */
        }
        .card h3, .card h5 {
            color: #ff4500; /* Tangerine for headings */
            text-shadow: 1px 1px 3px rgba(0, 0, 0, 0.5); /* Stronger shadow for visibility */
        }
        .card p {
            color: #2d3436;
            text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.3); /* Shadow for visibility */
        }
        .chart-container {
            background: rgba(255, 255, 255, 0.98); /* More opaque for better text visibility */
            border: 2px solid #d4af37;
            border-radius: 15px;
            padding: 20px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2); /* Stronger shadow for depth */
        }
        .table {
            background: rgba(255, 255, 255, 0.98); /* More opaque for better text visibility */
        }
        .table th, .table td {
            color: #2d3436;
            text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.3); /* Shadow for visibility */
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="container-fluid">
            <a href="admin_dashboard.php" class="navbar-brand">
                <img src="/project/img/logo.png" height="35" width="150" alt="Laptopmania">
            </a>
            <a class="btn btn-danger" href="logout.php">Logout</a>
        </div>
    </nav>

    <div class="container mt-5">
        <h3 class="mb-4">Welcome, Admin (<?= htmlspecialchars($_SESSION['admin']) ?>)</h3>
        <div class="row text-center">
            <div class="col-md-4">
                <div class="card shadow-sm p-3">
                    <h5>Total Products</h5>
                    <h3><?= $product_count ?></h3>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card shadow-sm p-3">
                    <h5>Total Categories</h5>
                    <h3><?= $category_count ?></h3>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card shadow-sm p-3">
                    <h5>Total Sales</h5>
                    <h3><?= $sales_count ?> Orders - $<?= number_format($sales_total, 2) ?></h3>
                </div>
            </div>
        </div>
        <div class="row mt-4">
            <div class="col-md-6">
                <div class="card shadow-sm text-center p-3">
                    <div class="card-body">
                        <h5><i class="bi bi-laptop"></i> Manage Products</h5>
                        <a href="manage_products.php" class="btn btn-primary">Manage Products</a>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card shadow-sm text-center p-3">
                    <div class="card-body">
                        <h5><i class="bi bi-tags"></i> Manage Categories</h5>
                        <a href="add_category.php" class="btn btn-primary">Add Category</a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Sales Analysis Section -->
        <div class="row mt-5">
            <div class="col-12">
                <h4 class="mb-4">Sales Analysis</h4>
            </div>
            <!-- Monthly Sales Chart -->
            <div class="col-md-6">
                <div class="chart-container">
                    <h5>Monthly Sales Trend (Last 12 Months)</h5>
                    <canvas id="monthlySalesChart"></canvas>
                </div>
            </div>
            <!-- Sales by Category Table -->
            <div class="col-md-6">
                <div class="card shadow-sm p-3">
                    <h5>Sales by Category</h5>
                    <?php if (empty($sales_by_category)): ?>
                        <p>No sales data available.</p>
                    <?php else: ?>
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Category</th>
                                    <th>Orders</th>
                                    <th>Total Sales</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($sales_by_category as $category): ?>
                                    <tr>
                                        <td><?= htmlspecialchars($category['name']) ?></td>
                                        <td><?= htmlspecialchars($category['order_count']) ?></td>
                                        <td>$<?= number_format($category['total_sales'], 2) ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <footer class="footer text-center py-3 mt-5">
        <p>© <?= date('Y') ?> Laptopmania. All Rights Reserved.</p>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        // Monthly Sales Chart
        const ctx = document.getElementById('monthlySalesChart').getContext('2d');
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: <?= json_encode($labels) ?>,
                datasets: [{
                    label: 'Sales ($)',
                    data: <?= json_encode($monthly_sales) ?>,
                    borderColor: '#ff4500', /* Tangerine for line */
                    backgroundColor: 'rgba(255, 69, 0, 0.3)', /* Slightly more opaque fill */
                    fill: true,
                    tension: 0.4
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: { 
                            color: '#2d3436', /* Darker ticks for visibility */
                            font: { size: 14 } /* Larger font for readability */
                        },
                        grid: { 
                            color: '#d4af37', /* Gold grid lines */
                            borderColor: '#2d3436' /* Darker border for axis */
                        }
                    },
                    x: {
                        ticks: { 
                            color: '#2d3436', /* Darker ticks for visibility */
                            font: { size: 14 } /* Larger font for readability */
                        },
                        grid: { 
                            color: '#d4af37', /* Gold grid lines */
                            borderColor: '#2d3436' /* Darker border for axis */
                        }
                    }
                },
                plugins: {
                    legend: {
                        labels: { 
                            color: '#2d3436', /* Darker legend text */
                            font: { size: 14 } /* Larger font for readability */
                        }
                    }
                }
            }
        });
    </script>
</body>
</html>