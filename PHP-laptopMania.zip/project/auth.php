<?php
session_start();
include 'db_connect.php';

// Function to check login attempts
function checkLoginAttempts($conn, $username) {
    $stmt = $conn->prepare("SELECT attempts, last_attempt FROM login_attempts WHERE email = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if ($result) {
        $attempts = $result['attempts'];
        $lastAttempt = strtotime($result['last_attempt']);
        $currentTime = time();

        if ($attempts >= 5 && ($currentTime - $lastAttempt < 300)) {
            return "Too many failed attempts. Please try again in 5 minutes.";
        }
    }
    return null;
}

// Function to update login attempts
function updateLoginAttempts($conn, $username, $success) {
    if ($success) {
        $stmt = $conn->prepare("DELETE FROM login_attempts WHERE email = ?");
        $stmt->bind_param("s", $username);
    } else {
        $stmt = $conn->prepare("INSERT INTO login_attempts (email, attempts, last_attempt)
            VALUES (?, 1, NOW()) ON DUPLICATE KEY UPDATE attempts = attempts + 1, last_attempt = NOW()");
        $stmt->bind_param("s", $username);
    }
    $stmt->execute();
    $stmt->close();
}
?>
