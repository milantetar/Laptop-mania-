<?php
session_start();
require 'db_connect.php';

if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}

$error = $success = "";
$product = null;
$product_id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

if (!$product_id) {
    header("Location: manage_products.php");
    exit();
}

$stmt = $conn->prepare("SELECT name, description, price, image_path, category_id FROM products WHERE id = ?");
$stmt->bind_param("i", $product_id);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows === 1) {
    $product = $result->fetch_assoc();
} else {
    header("Location: manage_products.php");
    exit();
}
$stmt->close();

$categories = [];
$stmt = $conn->prepare("SELECT id, name FROM categories");
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $categories[] = $row;
}
$stmt->close();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $product_name = filter_input(INPUT_POST, 'product_name', FILTER_SANITIZE_STRING);
    $product_description = filter_input(INPUT_POST, 'product_description', FILTER_SANITIZE_STRING);
    $product_price = filter_input(INPUT_POST, 'product_price', FILTER_VALIDATE_FLOAT);
    $category_id = filter_input(INPUT_POST, 'category_id', FILTER_VALIDATE_INT);
    $product_image = $_FILES['product_image'] ?? null;

    if (!$product_name || !$product_description || $product_price === false || !$category_id) {
        $error = "All fields except image are required.";
    } else {
        $image_path = $product['image_path'];
        if ($product_image && is_uploaded_file($product_image['tmp_name'])) {
            $image_path = "/project/img/" . basename($product_image['name']);
            if (!move_uploaded_file($product_image['tmp_name'], $_SERVER['DOCUMENT_ROOT'] . $image_path)) {
                $error = "Failed to upload new image.";
            }
        }

        if (!$error) {
            $stmt = $conn->prepare("UPDATE products SET name = ?, description = ?, price = ?, image_path = ?, category_id = ? WHERE id = ?");
            $stmt->bind_param("ssdssi", $product_name, $product_description, $product_price, $image_path, $category_id, $product_id);
            if ($stmt->execute()) {
                $success = "Product updated successfully!";
                header("Location: manage_products.php?success=" . urlencode($success));
                exit();
            } else {
                $error = "Error updating product: " . $conn->error;
            }
            $stmt->close();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Product - Laptopmania</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="/project/styles.css">
    <style>
        .container {
            max-width: 600px;
            background: rgba(255, 255, 255, 0.98);
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
            margin-top: 50px;
            position: relative;
            z-index: 1;
        }
        h2 {
            text-align: center;
            margin-bottom: 20px;
            font-weight: 600;
            color: #ff4500; /* Tangerine */
            text-shadow: 1px 1px 3px rgba(0, 0, 0, 0.5);
        }
        .form-control {
            border-radius: 8px;
            background: rgba(255, 255, 255, 0.95);
            color: #2d3436;
            border: 1px solid #d4af37; /* Gold border */
        }
        .form-control::placeholder {
            color: #6c757d;
        }
        .form-control:focus {
            border-color: #20b2aa; /* Seafoam green */
            box-shadow: 0 0 10px rgba(32, 178, 170, 0.5);
        }
        .form-label {
            color: #2d3436;
            text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.3);
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="container">
            <a class="navbar-brand" href="admin_dashboard.php">
                <img src="/project/img/logo.png" alt="Laptopmania Logo" width="150" height="35">
            </a>
            <a href="logout.php" class="btn btn-danger">Logout</a>
        </div>
    </nav>

    <div class="container">
        <h2><i class="bi bi-laptop"></i> Edit Product</h2>
        <?php if ($success): ?>
            <div class="alert alert-success"><?= $success ?></div>
        <?php elseif ($error): ?>
            <div class="alert alert-danger"><?= $error ?></div>
        <?php endif; ?>

        <form action="edit_product.php?id=<?= $product_id ?>" method="POST" enctype="multipart/form-data">
            <div class="mb-3">
                <label for="productName" class="form-label">Product Name</label>
                <input type="text" class="form-control" id="productName" name="product_name" value="<?= htmlspecialchars($product['name']) ?>" required>
            </div>
            <div class="mb-3">
                <label for="productDescription" class="form-label">Product Description</label>
                <textarea class="form-control" id="productDescription" name="product_description" rows="4" required><?= htmlspecialchars($product['description']) ?></textarea>
            </div>
            <div class="mb-3">
                <label for="productPrice" class="form-label">Product Price ($)</label>
                <input type="number" step="0.01" class="form-control" id="productPrice" name="product_price" value="<?= $product['price'] ?>" required>
            </div>
            <div class="mb-3">
                <label for="categoryId" class="form-label">Category</label>
                <select class="form-control" id="categoryId" name="category_id" required>
                    <option value="">Select a category</option>
                    <?php foreach ($categories as $category): ?>
                        <option value="<?= $category['id'] ?>" <?= $category['id'] == $product['category_id'] ? 'selected' : '' ?>><?= htmlspecialchars($category['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="mb-3">
                <label for="productImage" class="form-label">Product Image (Current: <img src="<?= $product['image_path'] ?>" width="50">) - Optional</label>
                <input type="file" class="form-control" id="productImage" name="product_image" accept="image/*">
            </div>
            <button type="submit" class="btn btn-primary">Update Product</button>
        </form>
    </div>

    <footer class="footer text-center py-3 mt-4">
        <p>© <?= date('Y') ?> Laptopmania. All rights reserved.</p>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>