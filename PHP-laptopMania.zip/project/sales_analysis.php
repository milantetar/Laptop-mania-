<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sales Analysis - Laptopmania</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            background-color: #212529;
            color: #f8f9fa;
        }

        .card {
            background-color: #343a40;
            border: none;
            color: #f8f9fa;
        }

        .table-dark th, .table-dark td {
            color: #f8f9fa;
        }

        .navbar-brand img {
            height: 40px;
        }
    </style>
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
        <img src="/project/img/logo.png" height="35" width="150" alt="Laptopmania">
        </div>
    </nav>

    <div class="container mt-4">
        <h2 class="text-center">Sales Analysis</h2>

        <div class="row g-4">
            <div class="col-md-4">
                <div class="card p-3 text-center">
                    <h5>Total Sales</h5>
                    <h3>$12,340</h3>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card p-3 text-center">
                    <h5>Total Orders</h5>
                    <h3>450</h3>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card p-3 text-center">
                    <h5>Total Revenue</h5>
                    <h3>$78,560</h3>
                </div>
            </div>
        </div>

        <div class="card mt-4 p-3">
            <h4>Sales Trends</h4>
            <canvas id="salesChart"></canvas>
        </div>

        <div class="card mt-4 p-3">
            <h4>Recent Orders</h4>
            <table class="table table-dark table-striped">
                <thead>
                    <tr>
                        <th>Order ID</th>
                        <th>Customer</th>
                        <th>Amount</th>
                        <th>Date</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>#1023</td>
                        <td>John Doe</td>
                        <td>$450</td>
                        <td>Feb 10, 2025</td>
                    </tr>
                    <tr>
                        <td>#1024</td>
                        <td>Jane Smith</td>
                        <td>$320</td>
                        <td>Feb 11, 2025</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>

    <footer class="footer mt-4 bg-dark text-center text-light py-3">
        <p>&copy; 2025 Laptopmania. All Rights Reserved.</p>
    </footer>

    <script>
        const ctx = document.getElementById('salesChart').getContext('2d');
        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
                datasets: [{
                    label: 'Sales ($)',
                    data: [1200, 1900, 3000, 5000, 2400, 3100],
                    backgroundColor: '#ffc107'
                }]
            }
        });
    </script>
</body>
</html>
