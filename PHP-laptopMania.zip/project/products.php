<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}

$user_email = htmlspecialchars($_SESSION['user']['email']);

// Database connection
require 'db_connect.php';

// Fetch products from database
$products = [];
$stmt = $conn->prepare("SELECT id, name, price, image_path FROM products");
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $products[] = [
        'id' => $row['id'],
        'name' => $row['name'],
        'price' => $row['price'],
        'image' => $row['image_path'] ?: '/project/img/placeholder.jpg'
    ];
}
$stmt->close();

// Add to Cart functionality
if (isset($_POST['add_to_cart'])) {
    $product_id = filter_input(INPUT_POST, 'product_id', FILTER_VALIDATE_INT);
    $quantity = filter_input(INPUT_POST, 'quantity', FILTER_VALIDATE_INT);

    if ($product_id && $quantity > 0) {
        if (!isset($_SESSION['cart'])) {
            $_SESSION['cart'] = [];
        }

        if (isset($_SESSION['cart'][$product_id])) {
            $_SESSION['cart'][$product_id]['quantity'] += $quantity;
        } else {
            $product_stmt = $conn->prepare("SELECT name, price, image_path FROM products WHERE id = ?");
            $product_stmt->bind_param("i", $product_id);
            $product_stmt->execute();
            $product_result = $product_stmt->get_result();
            if ($product = $product_result->fetch_assoc()) {
                $_SESSION['cart'][$product_id] = [
                    'name' => $product['name'],
                    'price' => $product['price'],
                    'quantity' => $quantity,
                    'image' => $product['image_path'] ?: '/project/img/placeholder.jpg'
                ];
            }
            $product_stmt->close();
        }
        header("Location: products.php?success=Added to cart!");
        exit();
    } else {
        echo "<script>alert('Please enter a valid quantity');</script>";
    }
}

// Clear cart functionality
if (isset($_POST['clear_cart'])) {
    unset($_SESSION['cart']);
}

// Calculate total price
$total = 0;
if (isset($_SESSION['cart'])) {
    foreach ($_SESSION['cart'] as $item) {
        $total += $item['price'] * $item['quantity'];
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Products - Laptopmania</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/project/styles.css">
    <style>
        .container { position: relative; z-index: 1; }
        .cart-summary {
            background: rgba(255, 255, 255, 0.9);
            backdrop-filter: blur(10px);
            border: 2px solid #d4af37;
            border-radius: 15px;
            padding: 15px;
        }
        .cart-summary h5 { color: #ff4500; }
        .list-group-item {
            background: transparent;
            color: #2d3436;
            border-color: #d4af37;
        }
        .total { font-weight: bold; color: #2d3436; }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg">
        <div class="container-fluid">
            <a class="navbar-brand" href="/project/homepage.php">
                <img src="/project/img/logo.png" height="35" width="150" alt="Laptopmania Logo">
            </a>
            <form class="d-flex ms-auto search-bar-container" action="search.php" method="GET">
                <input class="form-control me-2 search-bar" type="text" name="query" placeholder="Search" required>
                <button class="btn search-button" type="submit">Search</button>
            </form>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link" href="/project/homepage.php">Home</a></li>
                    <li class="nav-item"><a class="nav-link active" href="/project/products.php">Products</a></li>
                    <li class="nav-item"><a class="nav-link" href="/project/contactus.php">Contact</a></li>
                    <li class="nav-item"><a class="nav-link" href="/project/logout.php">Logout</a></li>
                </ul>
                <div class="d-flex align-items-center ms-3 profile-icon">
                    <a href="/project/profile.php" class="text-decoration-none d-flex align-items-center">
                        <div class="profile-image">
                            <img src="/project/img/user.png" alt="Profile" class="rounded-circle me-2">
                        </div>
                        <span class="text-white"><?= $user_email; ?></span>
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="row">
            <div class="col-md-9">
                <div class="row">
                    <?php foreach ($products as $product): ?>
                        <div class="col-md-4 mb-4">
                            <div class="product-card">
                                <img src="<?= htmlspecialchars($product['image']) ?>" 
                                     alt="<?= htmlspecialchars($product['name']) ?>" 
                                     class="product-image" 
                                     onerror="this.src='/project/img/placeholder.jpg';">
                                <div class="product-details">
                                    <h6 class="mt-2"><?= htmlspecialchars($product['name']) ?></h6>
                                    <p>$<?= number_format($product['price'], 2) ?></p>
                                    <form method="POST" action="">
                                        <input type="hidden" name="product_id" value="<?= $product['id'] ?>">
                                        <input type="number" name="quantity" value="1" min="1" class="form-control mb-2" required>
                                        <button type="submit" name="add_to_cart" class="btn btn-primary">Add to Cart</button>
                                        <a href="product_details.php?id=<?= $product['id'] ?>" class="btn btn-info mt-2">View Details</a>
                                    </form>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
                <?php if (isset($_GET['success'])): ?>
                    <div class="alert alert-success mt-3"><?= htmlspecialchars($_GET['success']) ?></div>
                <?php endif; ?>
            </div>
            <div class="col-md-3">
                <div class="cart-summary">
                    <h5>Shopping Cart</h5>
                    <?php if (isset($_SESSION['cart']) && !empty($_SESSION['cart'])): ?>
                        <ul class="list-group list-group-flush">
                            <?php foreach ($_SESSION['cart'] as $item): ?>
                                <li class="list-group-item">
                                    <?= htmlspecialchars($item['name']) ?> - $<?= number_format($item['price'], 2) ?> x <?= $item['quantity'] ?>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    <?php else: ?>
                        <p class="text-center">Cart is empty</p>
                    <?php endif; ?>
                    <p class="mt-3">Sub Total: <span class="total">$<?= number_format($total, 2) ?></span></p>
                    <form method="POST" action="">
                        <button type="submit" name="clear_cart" class="btn btn-danger w-100">Clear Cart</button>
                    </form>
                    <a href="/project/checkout.php" class="btn btn-success w-100 mt-3 <?= empty($_SESSION['cart']) ? 'disabled' : '' ?>">Proceed to Buy</a>
                </div>
            </div>
        </div>
    </div>

    <footer class="footer text-center py-3">
        <img src="/project/img/logo.png" height="35" width="140" alt="Laptopmania Logo">
        <p>© <?= date("Y"); ?> Laptopmania. All rights reserved.</p>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>