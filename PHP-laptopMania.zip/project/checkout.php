<?php
session_start();

if (!isset($_SESSION['user'])) {
    echo "<script>alert('Please log in to place an order!'); window.location.href='login.php';</script>";
    exit();
}

if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
    echo "<script>alert('Your cart is empty!'); window.location.href='products.php';</script>";
    exit();
}

require 'db_connect.php';

if (isset($_POST['remove_item'])) {
    $product_id = $_POST['product_id'];
    unset($_SESSION['cart'][$product_id]);
    header("Location: checkout.php");
    exit();
}

$total = 0;
foreach ($_SESSION['cart'] as $item) {
    $total += $item['price'] * $item['quantity'];
}

if (isset($_POST['place_order'])) {
    $user_id = $_SESSION['user']['id'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $address = $_POST['address'];

    try {
        $conn->begin_transaction();

        foreach ($_SESSION['cart'] as $product_id => $item) {
            $quantity = $item['quantity'];
            $price = $item['price'] * $item['quantity'];

            $stmt = $conn->prepare("
                INSERT INTO orders (user_id, product_id, quantity, price, order_date)
                VALUES (?, ?, ?, ?, NOW())
            ");
            $stmt->bind_param("iiid", $user_id, $product_id, $quantity, $price);
            $stmt->execute();
            $stmt->close();
        }

        $conn->commit();

        $_SESSION['order'] = [
            'name' => $name,
            'email' => $email,
            'address' => $address,
            'cart' => $_SESSION['cart'],
            'total' => $total,
            'order_date' => date('Y-m-d H:i:s')
        ];

        unset($_SESSION['cart']);

        echo "<script>alert('Order placed successfully!'); window.location.href='order_confirmation.php';</script>";
        exit();
    } catch (Exception $e) {
        $conn->rollback();
        echo "<script>alert('Error placing order: " . $e->getMessage() . "'); window.location.href='checkout.php';</script>";
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout - Laptopmania</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/project/styles.css">
    <style>
        .container {
            position: relative;
            z-index: 1;
        }
        h2, h4, h5 {
            color: #ff4500; /* Tangerine */
            text-shadow: 1px 1px 3px rgba(0, 0, 0, 0.5);
        }
        .table th, .table td {
            color: #2d3436;
            text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.3);
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg">
        <div class="container-fluid">
            <img src="/project/img/logo.png" height="35px" width="150px" alt="logo">
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link" href="/project/products.php">Continue Shopping</a></li>
                    <li class="nav-item"><a class="nav-link" href="/project/logout.php">Logout</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <h2>Checkout</h2>

        <table class="table">
            <thead>
                <tr>
                    <th>Product</th>
                    <th>Quantity</th>
                    <th>Price</th>
                    <th>Total</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($_SESSION['cart'] as $id => $item): ?>
                    <tr>
                        <td><?= htmlspecialchars($item['name']) ?></td>
                        <td><?= htmlspecialchars($item['quantity']) ?></td>
                        <td>$<?= number_format($item['price'], 2) ?></td>
                        <td>$<?= number_format($item['price'] * $item['quantity'], 2) ?></td>
                        <td>
                            <form method="POST">
                                <input type="hidden" name="product_id" value="<?= htmlspecialchars($id) ?>">
                                <button type="submit" name="remove_item" class="btn btn-danger btn-sm">Remove</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <h4>Total: $<?= number_format($total, 2) ?></h4>

        <form method="POST" class="mt-4">
            <h5>Shipping Information</h5>
            <div class="mb-3">
                <label class="form-label">Name</label>
                <input type="text" name="name" class="form-control" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Email</label>
                <input type="email" name="email" class="form-control" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Address</label>
                <textarea name="address" class="form-control" required></textarea>
            </div>
            <button type="submit" name="place_order" class="btn btn-success w-100">Place Order</button>
        </form>
    </div>

    <footer class="footer mt-4 text-center">
        <img src="/project/img/logo.png" height="35px" width="140px" alt="logo">
        <p>© <?= date("Y"); ?> Laptopmania. All rights reserved.</p>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>