<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['user'])) {
    header("Location: login.php"); // Redirect to login page if not logged in
    exit();
}

// Check if product details are provided via POST
if (isset($_POST['product_id']) && isset($_POST['product_name']) && isset($_POST['product_price'])) {
    $product_id = $_POST['product_id'];
    $product_name = $_POST['product_name'];
    $product_price = $_POST['product_price'];

    // Initialize the cart session if not already set
    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }

    // Check if the product already exists in the cart
    $product_found = false;
    foreach ($_SESSION['cart'] as $index => $item) {
        if ($item['id'] == $product_id) {
            $_SESSION['cart'][$index]['quantity'] += 1; // Increase quantity if product is already in the cart
            $product_found = true;
            break;
        }
    }

    // If the product wasn't found in the cart, add it
    if (!$product_found) {
        $_SESSION['cart'][] = [
            'id' => $product_id,
            'name' => $product_name,
            'price' => $product_price,
            'quantity' => 1
        ];
    }

    // Redirect back to the homepage or categories page
    header("Location: homepage.php"); // Or categories.php, depending on where the user is
    exit();
}
?>
