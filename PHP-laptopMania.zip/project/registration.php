<?php
declare(strict_types=1);
session_start();
require 'db_connect.php';

// Redirect authenticated users
if (isset($_SESSION['user'])) {
    header("Location: homepage.php");
    exit();
}

$error = "";

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fullname = filter_input(INPUT_POST, 'fullname', FILTER_SANITIZE_STRING);
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    $terms = isset($_POST['terms']) ? true : false;

    // Simple form validation
    if (!$fullname || !$email || !$password || !$confirm_password) {
        $error = "All fields are required.";
    } elseif ($password !== $confirm_password) {
        $error = "Passwords do not match.";
    } elseif (!$terms) {
        $error = "You must agree to the terms and conditions.";
    } else {
        // Check if the email already exists
        $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
        if (!$stmt) {
            die("Database error: " . $conn->error);
        }

        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $error = "Email is already taken.";
        } else {
            // Hash the password for security
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);

            // Insert the user into the database
            $stmt = $conn->prepare("INSERT INTO users (fullname, email, password, created_at) VALUES (?, ?, ?, NOW())");
            if (!$stmt) {
                die("Database error: " . $conn->error);
            }

            $stmt->bind_param("sss", $fullname, $email, $hashed_password);
            if ($stmt->execute()) {
                $_SESSION['user'] = [
                    'fullname' => $fullname,
                    'email' => $email
                ];
                session_regenerate_id(true);
                header("Location: homepage.php");
                exit();
            } else {
                $error = "Error registering user. Please try again later.";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en" data-bs-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Register to Laptopmania - Your premier laptop destination">
    <title>Register - Laptopmania</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="/project/styles.css">
    <style>
        /* Classy tangerine K-drama theme */
        .auth-container {
            min-height: 100vh;
            display: grid;
            place-items: center;
            position: relative;
            overflow: hidden;
        }
        .auth-container::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320"><path fill="rgba(255,255,255,0.2)" fill-opacity="1" d="M0,160L48,176C96,192,192,224,288,213.3C384,203,480,149,576,138.7C672,128,768,160,864,181.3C960,203,1056,213,1152,197.3C1248,181,1344,139,1392,117.3L1440,96L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"></path></svg>') repeat-x bottom;
            animation: waveMove 10s linear infinite;
        }
        .card {
            width: 100%;
            max-width: 400px;
            background: rgba(255, 255, 255, 0.9); /* Glassmorphism effect */
            backdrop-filter: blur(10px);
            border: 2px solid #d4af37; /* Gold border */
            border-radius: 15px;
            box-shadow: 0 0 20px rgba(212, 175, 55, 0.3);
        }
        .card h2 {
            font-family: 'Playfair Display', serif;
            color: #ff4500; /* Tangerine */
            text-shadow: 0 0 5px rgba(255, 69, 0, 0.3);
        }
        .input-group-text.toggle-password {
            cursor: pointer;
            background: linear-gradient(45deg, #ff8c00, #ffd700); /* Tangerine to yellow */
            color: #2d3436;
            border: 1px solid #d4af37; /* Gold border */
        }
        .text-center a {
            color: #1e90ff;
        }
        .text-center a:hover {
            color: #40c4ff;
            text-shadow: 0 0 10px rgba(64, 196, 255, 0.7);
        }
    </style>
</head>
<body class="d-flex flex-column min-vh-100">
    <nav class="navbar">
        <div class="container">
            <a class="navbar-brand" href="#">
                <img src="/project/img/logo.png" alt="Laptopmania Logo" width="150" height="35">
            </a>
        </div>
    </nav>

    <main class="auth-container">
        <div class="card shadow-lg">
            <div class="card-body p-4">
                <div class="text-center mb-4">
                    <img src="/project/img/logo.png" alt="Logo" width="120" class="mb-3">
                    <h2 class="h4">Create your account</h2>
                </div>

                <?php if ($error): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <?= htmlspecialchars($error) ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
                <?php endif; ?>

                <form method="POST" autocomplete="off" onsubmit="return validateForm()">
                    <div class="mb-3">
                        <label for="fullname" class="form-label">Full Name</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="bi bi-person-check"></i></span>
                            <input type="text" class="form-control" id="fullname" name="fullname" placeholder="Enter fullname" required>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label for="email" class="form-label">Email address</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="bi bi-envelope"></i></span>
                            <input type="email" class="form-control" id="email" name="email" placeholder="name@example.com" required>
                        </div>
                    </div>

                    <div class="mb-4">
                        <label for="password" class="form-label">Password</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="bi bi-lock"></i></span>
                            <input type="password" class="form-control" id="password" name="password" placeholder="••••••••" required>
                            <span class="input-group-text toggle-password" onclick="togglePassword('password', this)">
                                <i class="bi bi-eye-slash"></i>
                            </span>
                        </div>
                    </div>

                    <div class="mb-4">
                        <label for="confirm_password" class="form-label">Confirm Password</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="bi bi-lock"></i></span>
                            <input type="password" class="form-control" id="confirm_password" name="confirm_password" placeholder="••••••••" required>
                            <span class="input-group-text toggle-password" onclick="togglePassword('confirm_password', this)">
                                <i class="bi bi-eye-slash"></i>
                            </span>
                        </div>
                    </div>

                    <div class="mb-4">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" id="terms" name="terms" required>
                            <label class="form-check-label" for="terms">I agree to the <a href="#">Terms and Conditions</a></label>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary w-100 mb-3">
                        <i class="bi bi-person-check me-2"></i>Register
                    </button>

                    <div class="text-center">
                        <p class="text-muted">Already registered? 
                            <a href="/project/login.php" class="text-decoration-none">Login</a>
                        </p>
                    </div>
                </form>
            </div>
        </div>
    </main>

    <footer class="footer mt-auto">
        <div class="container py-4">
            <p class="text-center small">© <?= date('Y') ?> Laptopmania. All rights reserved.</p>
        </div>
    </footer>

    <script>
        function togglePassword(fieldId, iconElement) {
            var passwordField = document.getElementById(fieldId);
            var icon = iconElement.querySelector("i");

            if (passwordField.type === "password") {
                passwordField.type = "text";
                icon.classList.remove("bi-eye-slash");
                icon.classList.add("bi-eye");
            } else {
                passwordField.type = "password";
                icon.classList.remove("bi-eye");
                icon.classList.add("bi-eye-slash");
            }
        }

        function validateForm() {
            var fullname = document.getElementById('fullname').value;
            var email = document.getElementById('email').value;
            var password = document.getElementById('password').value;
            var confirm_password = document.getElementById('confirm_password').value;

            if (!fullname || !email || !password || !confirm_password) {
                alert("Please fill in all fields.");
                return false;
            }

            if (password !== confirm_password) {
                alert("Passwords do not match.");
                return false;
            }

            return true;
        }
    </script>
</body>
</html>