<?php
session_start();
require 'db_connect.php';

if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $product_id = filter_input(INPUT_POST, 'product_id', FILTER_VALIDATE_INT);

    if ($product_id) {
        $stmt = $conn->prepare("DELETE FROM products WHERE id = ?");
        $stmt->bind_param("i", $product_id);
        if ($stmt->execute()) {
            $success = "Product deleted successfully!";
            header("Location: manage_products.php?success=" . urlencode($success));
            exit();
        } else {
            $error = "Error deleting product: " . $conn->error;
            header("Location: manage_products.php?error=" . urlencode($error));
            exit();
        }
        $stmt->close();
    } else {
        header("Location: manage_products.php");
        exit();
    }
} else {
    header("Location: manage_products.php");
    exit();
}
?>