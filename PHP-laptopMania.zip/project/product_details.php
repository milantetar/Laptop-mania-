<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}

$user_email = htmlspecialchars($_SESSION['user']['email']);

// Database connection
require 'db_connect.php';

// Fetch product details based on ID from URL parameter
$product = null;
$product_id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

if ($product_id) {
    $stmt = $conn->prepare("SELECT id, name, description, price, image_path FROM products WHERE id = ?");
    $stmt->bind_param("i", $product_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($product = $result->fetch_assoc()) {
        $product['image'] = $product['image_path'] ?: '/project/img/placeholder.jpg';
    }
    $stmt->close();
}

if (!$product) {
    die("Product not found.");
}

// Add to Cart functionality
if (isset($_POST['add_to_cart'])) {
    $quantity = filter_input(INPUT_POST, 'quantity', FILTER_VALIDATE_INT);

    if ($quantity > 0) {
        if (!isset($_SESSION['cart'])) {
            $_SESSION['cart'] = [];
        }

        if (isset($_SESSION['cart'][$product_id])) {
            $_SESSION['cart'][$product_id]['quantity'] += $quantity;
        } else {
            $_SESSION['cart'][$product_id] = [
                'name' => $product['name'],
                'price' => $product['price'],
                'quantity' => $quantity,
                'image' => $product['image']
            ];
        }
        header("Location: product_details.php?id=" . $product_id . "&success=Added to cart!");
        exit();
    } else {
        echo "<script>alert('Please enter a valid quantity');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Details - Laptopmania</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/project/styles.css">
    <style>
        .container { position: relative; z-index: 1; }
        .product-details {
            background: rgba(255, 255, 255, 0.9);
            backdrop-filter: blur(10px);
            border: 2px solid #d4af37;
            border-radius: 15px;
            padding: 20px;
            max-width: 800px;
            margin: 20px auto;
        }
        .product-details p { color: #2d3436; }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg">
        <div class="container-fluid">
            <a class="navbar-brand" href="/project/homepage.php">
                <img src="/project/img/logo.png" height="35" width="150" alt="Laptopmania Logo">
            </a>
            <form class="d-flex ms-auto search-bar-container" action="search.php" method="GET">
                <input class="form-control me-2 search-bar" type="text" name="query" placeholder="Search" required>
                <button class="btn search-button" type="submit">Search</button>
            </form>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link" href="/project/homepage.php">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="/project/products.php">Products</a></li>
                    <li class="nav-item"><a class="nav-link" href="/project/contactus.php">Contact</a></li>
                    <li class="nav-item"><a class="nav-link" href="/project/logout.php">Logout</a></li>
                </ul>
                <div class="d-flex align-items-center ms-3 profile-icon">
                    <a href="/project/profile.php" class="text-decoration-none d-flex align-items-center">
                        <div class="profile-image">
                            <img src="/project/img/user.png" alt="Profile" class="rounded-circle me-2">
                        </div>
                        <span class="text-white"><?= $user_email; ?></span>
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <div class="container">
        <div class="product-details">
            <h2><?= htmlspecialchars($product['name']) ?></h2>
            <?php if (isset($_GET['success'])): ?>
                <div class="alert alert-success"><?= htmlspecialchars($_GET['success']) ?></div>
            <?php endif; ?>
            <img src="<?= htmlspecialchars($product['image']) ?>" alt="<?= htmlspecialchars($product['name']) ?>" class="product-image" onerror="this.src='/project/img/placeholder.jpg';">
            <p class="mt-3"><strong>Description:</strong> <?= htmlspecialchars($product['description'] ?? 'No description available') ?></p>
            <p><strong>Price:</strong> $<?= number_format($product['price'], 2) ?></p>
            <form method="POST" action="">
                <input type="hidden" name="product_id" value="<?= $product['id'] ?>">
                <div class="mb-3">
                    <label for="quantity" class="form-label">Quantity:</label>
                    <input type="number" name="quantity" id="quantity" value="1" min="1" class="form-control" required>
                </div>
                <button type="submit" name="add_to_cart" class="btn btn-primary w-100">Add to Cart</button>
            </form>
            <a href="/project/products.php" class="btn btn-info w-100 mt-3">Back to Products</a>
        </div>
    </div>

    <footer class="footer text-center py-3">
        <img src="/project/img/logo.png" height="35" width="140" alt="Laptopmania Logo">
        <p>© <?= date("Y"); ?> Laptopmania. All rights reserved.</p>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>